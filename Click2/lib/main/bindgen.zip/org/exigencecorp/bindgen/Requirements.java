package org.exigencecorp.bindgen;

public class Requirements {

    public static final Requirement fixRawTypesByAddingGenericHints = new Requirement();

    public static class Requirement {
        public void fulfills() {
        }

        public void tests() {
        }
    }

}

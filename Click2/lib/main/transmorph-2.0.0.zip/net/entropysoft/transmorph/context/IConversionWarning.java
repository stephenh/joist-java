package net.entropysoft.transmorph.context;

public interface IConversionWarning {

	public String getMessage();
	
}

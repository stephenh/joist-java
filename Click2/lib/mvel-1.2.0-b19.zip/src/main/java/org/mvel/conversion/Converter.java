package org.mvel.conversion;

public interface Converter {
    public Object convert(Object o);
}

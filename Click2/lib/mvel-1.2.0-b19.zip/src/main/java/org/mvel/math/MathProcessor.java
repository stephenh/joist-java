package org.mvel.math;

/**
 * @author Christopher Brock
 */
public interface MathProcessor {
    public Object doOperation(Object val1, int operation, Object val2);
}

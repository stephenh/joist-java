package org.mvel.optimizers.impl.asm;

public class Sandbox {
}

package org.mvel.util;

public class ThisLiteral {
}

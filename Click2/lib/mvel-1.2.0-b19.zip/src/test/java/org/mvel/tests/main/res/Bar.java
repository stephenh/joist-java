package org.mvel.tests.main.res;

public class Bar {
    private String name = "dog";
    private boolean woof = true;
    private int age = 14;
    private String assignTest = "";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isWoof() {
        return woof;
    }

    public void setWoof(boolean woof) {
        this.woof = woof;
    }


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isFoo(Object obj) {
        return obj instanceof Foo;
    }


    public String getAssignTest() {
        return assignTest;
    }

    public void setAssignTest(String assignTest) {
        this.assignTest = assignTest;
    }
}

package org.mvel.tests.main.res;

public class DerivedClass extends Base {
}

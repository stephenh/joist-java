package org.exigencecorp.conversion;

public interface Converter {

    Class<?> convertsTo();

    boolean supportsFrom(Class<?> source);

    Object convert(Object value);

    void setConverterRegistry(ConverterRegistry registry);

}

package org.exigencecorp.conversion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class ConverterRegistry {

    private final ConcurrentMap<Class<?>, List<Converter>> converters = new ConcurrentHashMap<Class<?>, List<Converter>>();

    public synchronized void addConverter(Converter c) {
        List<Converter> list = this.converters.get(c.convertsTo());
        if (list == null) {
            list = Collections.synchronizedList(new ArrayList<Converter>());
            this.converters.put(c.convertsTo(), list);
        }
        list.add(c);
    }

    public Object convert(Object value, Class<?> type) {
        for (Class<?> currentType = type; currentType != null; currentType = currentType.getSuperclass()) {
            List<Converter> converters = this.converters.get(currentType);
            if (converters != null) {
                for (Converter c : converters) {
                    if (c.supportsFrom(value.getClass())) {
                        return c.convert(value);
                    }
                }
            }
        }
        return value;
    }

}

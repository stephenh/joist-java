package org.exigencecorp.conversion.converters;

import org.exigencecorp.conversion.Converter;
import org.exigencecorp.conversion.ConverterRegistry;

public class IntegerConverter implements Converter {

    private ConverterRegistry registry;

    public Class<?> convertsTo() {
        return Integer.class;
    }

    public boolean supportsFrom(Class<?> source) {
        return source.equals(String.class);
    }

    public Object convert(Object value) {
        if (value instanceof String) {
            return new Integer((String) value);
        }
        return null;
    }

    public void setConverterRegistry(ConverterRegistry registry) {
        this.registry = registry;
    }

}

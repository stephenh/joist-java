package org.exigencecorp.domainobjects;

public interface Code {

    Integer getId();

    String getCode();

    String getName();

}

package org.exigencecorp.domainobjects.codegen.passes;

import org.exigencecorp.domainobjects.codegen.Codegen;

public interface Pass {

    void pass(Codegen codegen);

}

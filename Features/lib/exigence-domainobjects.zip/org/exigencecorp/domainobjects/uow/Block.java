package org.exigencecorp.domainobjects.uow;

public interface Block {

    void go();

}

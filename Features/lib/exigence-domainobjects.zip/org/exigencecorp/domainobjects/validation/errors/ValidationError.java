package org.exigencecorp.domainobjects.validation.errors;

public interface ValidationError {

    String getMessage();

}
